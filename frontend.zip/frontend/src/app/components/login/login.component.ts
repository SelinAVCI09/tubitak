import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [], // Bu kısımda gerekli modülleri ekleyebilirsiniz, örneğin ReactiveFormsModule, FormsModule vb.
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] // Burada doğru özellik 'styleUrls' (çoğul) olmalı
})
export class LoginComponent {
  // Gerekli fonksiyonlar ve logic burada yer alabilir
}
