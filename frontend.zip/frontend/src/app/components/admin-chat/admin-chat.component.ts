import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-chat',
  standalone: true,
  imports: [],
  templateUrl: './admin-chat.component.html',
  styleUrl: './admin-chat.component.css'
})
export class AdminChatComponent {

}
