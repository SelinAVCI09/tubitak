import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { FormsModule } from '@angular/forms'; // Ensure FormsModule is imported
import { AppComponent } from './app.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule, // Import FormsModule here
    RouterModule.forRoot(routes)
  ],
  providers: []
})
export class AppModule { }

// Use bootstrapApplication to bootstrap the standalone component
import { bootstrapApplication } from '@angular/platform-browser';
bootstrapApplication(AppComponent);
